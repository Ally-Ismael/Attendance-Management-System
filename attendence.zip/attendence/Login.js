// Function to dynamically update the login form based on user role
function updateForm() {
    const role = document.getElementById('role').value;
    const loginForm = document.getElementById('login-form');

    if (role === 'admin') {
        loginForm.innerHTML = `
            <label for="adminID">Admin ID:</label>
            <input type="text" id="adminID" placeholder="Enter Admin ID" required>
            <label for="password">Password:</label>
            <input type="password" id="password" placeholder="Enter Password" required>
        `;
    } else if (role === 'lecturer') {
        loginForm.innerHTML = `
            <label for="lecturerID">Lecturer ID:</label>
            <input type="text" id="lecturerID" placeholder="Enter Lecturer ID" required>
            <label for="password">Password:</label>
            <input type="password" id="password" placeholder="Enter Password" required>
        `;
    } else if (role === 'student') {
        loginForm.innerHTML = `
            <label for="studentNumber">Student Number:</label>
            <input type="text" id="studentNumber" placeholder="Enter Student Number" required>
            <label for="password">Password:</label>
            <input type="password" id="password" placeholder="Enter Password" required>
        `;
    } else {
        loginForm.innerHTML = ''; // Clear form if no role is selected
    }
}

// Function to simulate login and redirect to respective dashboard
function login() {
    const role = document.getElementById('role').value;
    let id;
    let password = document.getElementById('password').value;

    if (role === 'admin') {
        id = document.getElementById('adminID').value;
        // Validate admin credentials (example only)
        if (id === 'admin123' && password === 'adminpass') {
            window.location.href = 'admin_dashboard.html';
        } else {
            alert('Invalid Admin ID or password');
        }
    } else if (role === 'lecturer') {
        id = document.getElementById('lecturerID').value;
        // Validate lecturer credentials
        if (id === 'lecturer123' && password === 'lecturerpass') {
            window.location.href = 'lecturer_dashboard.html';
        } else {
            alert('Invalid Lecturer ID or password');
        }
    } else if (role === 'student') {
        id = document.getElementById('studentNumber').value;
        // Validate student credentials
        if (id === 'student123' && password === 'studentpass') {
            window.location.href = 'student_dashboard.html';
        } else {
            alert('Invalid Student Number or password');
        }
    } else {
        alert('Please select a role and enter credentials');
    }
}
