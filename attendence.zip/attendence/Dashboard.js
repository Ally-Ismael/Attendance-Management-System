async function generateReport() {
    const response = await fetch('http://localhost:8080/admin/generateReport');
    const report = await response.json();
    alert(JSON.stringify(report));
}

async function takeAttendance() {
    const response = await fetch('http://localhost:8081/lecturer/takeAttendance', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({class: "CS101", date: "2024-10-08"})
    });
    const result = await response.json();
    alert(result.message);
}

async function viewAttendance() {
    const response = await fetch('http://localhost:8081/lecturer/viewAttendance');
    const attendance = await response.json();
    alert(JSON.stringify(attendance));
}

async function viewStudentAttendance() {
    const response = await fetch('http://localhost:8082/student/viewAttendance');
    const attendance = await response.json();
    alert(JSON.stringify(attendance));
}

async function checkNotifications() {
    const response = await fetch('http://localhost:8082/student/notifications');
    const notifications = await response.json();
    alert(JSON.stringify(notifications));
}
